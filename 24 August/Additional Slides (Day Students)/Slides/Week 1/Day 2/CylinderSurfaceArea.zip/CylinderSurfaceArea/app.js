
// Calculate surface area
let area = 2 * Math.PI * Math.pow(24.67, 2) + 2 * Math.PI * 24.67 * 12.13;

//5 sig figures
console.log(area.toPrecision(5));	


